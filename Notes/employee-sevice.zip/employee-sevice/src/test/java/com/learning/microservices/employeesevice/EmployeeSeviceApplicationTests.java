package com.learning.microservices.employeesevice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSeviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
